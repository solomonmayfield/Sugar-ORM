package com.example.mysugarormapplication.jobmodel;

import com.orm.SugarRecord;
import com.orm.dsl.Column;
import com.orm.dsl.Table;


@Table(name = "jobs_title")
public class Jobs extends SugarRecord {

    @Column(name = "job_title")
    private String JobTitle;

    public String getJobTitle() {
        return JobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.JobTitle = jobTitle;
    }
}
