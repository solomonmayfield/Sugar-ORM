package com.example.mysugarormapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

/**
 *
 *How Create Sqlite Sugar ORM crud application in Android Part 2
 *https://www.youtube.com/watch?v=FWTBSDR4dpc
 *
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
